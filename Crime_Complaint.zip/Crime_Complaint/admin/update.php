<?php require_once('includes/session.php');
      require_once('includes/conn.php');
$sqlE =mysqli_query($mysqli,"SELECT * FROM users WHERE username='{$_SESSION['username']}'");
$eprow=mysqli_fetch_array($sqlE);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>Cyber Crime | SECURITY - DASHBOARD</title>

         <!-- Bootstrap CSS CDN -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- Our Custom CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/awesome/font-awesome.css">
        <link rel="stylesheet" href="assets/css/animate.css">
    </head>
    <body>
<?php
function crimechain($uid,$uname,$bcdata,$utype)
{
    ############
	$mon=date("m");
    $rdate=date("d-m-Y");
   $ch1=mktime(date('h')+5,date('i')+30,date('s'));
$rtime=date('h:i:s A',$ch1);
    
    $ff=fopen("../key.txt","r");
    $k=fread($ff,filesize("../key.txt"));
    fclose($ff);
    
    #bcdata="CID:"+uname+",Time:"+val1+",Unit:"+val2
    $dtime=$rdate.",".$rtime;

    $ff1=fopen("../js/d1.txt","r");
    $bc1=fread($ff1,filesize("../js/d1.txt"));
    fclose($ff1);
    
    $px="";
    if($k=="1")
	{
        $px="";
		$rn=rand(100,999);
        $result = md5($bcdata);
        $key=substr($result,0,32);
        
        $v=$k."##".$key."##".$bcdata."##".$dtime;

		$ff1=fopen("../js/d1.txt","w");
    	fwrite($ff1,$v);
   		fclose($ff1);
       
        
        $dictionary = array(
            "ID"=> "1",
            "Pre-hash"=> "00000000000000000000000000000000",
            "Hash"=> $key,
            "utype"=> $utype,
            "Date/Time"=> $dtime
        );

        $k1=$k;
        $k2=$k1+1;
        $k3=$k2;
        $ff1=fopen("../key.txt","w");
        fwrite($ff1,$k3);
        fclose($ff1);
		
		$ff1=fopen("../prehash.txt","w");
        fwrite($ff1,$key);
        fclose($ff1);

   	  
    }    
    else
	{
        $px=",";
        $pre_k="";
        $k1=$k;
        $k2=$k1-1;
        $k4=$k2;

		$ff1=fopen("../prehash.txt","r");
        $pre_hash=fread($ff1,filesize("../prehash.txt"));
        fclose($ff1);
		
        
        $g1=explode("#|",$bc1);
        foreach($g1 as $g2)
		{
            $g3=explode("##",$g2);
            if($k4==$g3[0])
			{
                $pre_k=$g3[1];
                break;
			}
		}
        
        $result = md5($bcdata);
        $key=$result;
        

        $v="#|".$k."##".$key."##".$bcdata."##".$dtime;

        $k3=$k2;
		
		$ff1=fopen("../key.txt","w");
        fwrite($ff1,$k3);
        fclose($ff1);
        
		$ff1=fopen("../js/d1.txt","a");
        fwrite($ff1,$v);
        fclose($ff1);

        
        $dictionary = array(
            "ID"=> $k,
            "Pre-hash"=> $pre_hash,
            "Hash"=> $key,
            "utype"=> $utype,
            "Date/Time"=> $dtime
        );
        
        $k21=$k+1;
        $k3=$k21;
		
		$ff1=fopen("../key.txt","w");
        fwrite($ff1,$k3);
        fclose($ff1);
		
    	$ff1=fopen("../prehash.txt","w");
        fwrite($ff1,$key);
        fclose($ff1);

      
	
 	}
    # Serializing json
	$m="";
    if(k=="1")
	{
        $m="w";
	}
    else
	{
       $m="a";
	 }
	//$json_data = json_encode($dictionary, JSON_PRETTY_PRINT);
	$json_data = json_encode($dictionary);
// Write JSON to file
//file_put_contents("../crimechain.json", $json_data);
		$ff1=fopen("../crimechain.json",$m);
        fwrite($ff1,$json_data);
        fclose($ff1);

}

?>
       <div class="wrapper">
            <!-- Sidebar Holder -->
            <nav id="sidebar" class="sammacmedia">
                <div class="sidebar-header">
                    <h3>Cyber Crime </h3>
                    <strong>CC</strong>
                </div>

                <ul class="list-unstyled components">
                    <li class="active">
                        <a href="dashboard.php">
                            <i class="fa fa-th"></i>
                           Dashboard
                        </a>
                    </li>
                              <?php
                    //if($_SESSION['permission']==1 or $_SESSION['permission']==2 ){
                        
                    
                    ?>
                    
                    <li>
                        <a href="v_issue.php">
                            <i class="fa fa-table"></i>
                            View Issues
                        </a>
                    </li>
					<?php //}?>
                             <?php
                   // if($_SESSION['permission']==1){
                    ?>
                  
                    
                    <?php //}?>
                             <?php
                   // if($_SESSION['permission']==1){
                    ?>
                  
                    <li>
                        <a href="v_users.php">
                            <i class="fa fa-table"></i>
                            View Users
                        </a>
                    </li>
                    <?php //} ?>
					                    <li>
                        <a href="update.php">
                            <i class="fa fa-cog"></i>
                            Case Update
                        </a>
                    </li>
                    <li >
                        <a href="logout.php">
                            <i class="fa fa-link"></i>
                           Logout
                        </a>
                    </li>
                </ul>
            </nav>

            <!-- Page Content Holder -->
            <div id="content">
             
                <div clas="col-md-12">
                    <img src="assets/image/line.png" class="img-thumbnail">
                    </div>
         
                
                <nav class="navbar navbar-default sammacmedia">
                    <div class="container-fluid">

                        <div class="navbar-header" id="sams">
                            <button type="button" id="sidebarCollapse" id="makota" class="btn btn-sam animated tada navbar-btn">
                                <i class="glyphicon glyphicon-align-left"></i>
                                <span>Menu</span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav navbar-right  makotasamuel">
                                <li><a href="#"><?php require_once('includes/name.php');?></a></li>
                                <li ><a href="logout.php"><i class="fa fa-power-off"> Logout</i></a></li>
           
                            </ul>
                        </div>
                    </div>
                </nav>
                                                  
                            <?php
                            if(isset($mysqli,$_POST['submit'])){
                            $case_num =mysqli_real_escape_string($mysqli,$_POST['case_num']);
                            $Status =mysqli_real_escape_string($mysqli,$_POST['Status']);
							
							$qq=mysqli_query($mysqli,"select * from cases where case_num='$case_num'");
							$rr=mysqli_fetch_array($qq);
							$uname=$rr['uname'];
							$id=$rr['id'];
                        
                                $sqliU ="UPDATE cases SET Status='$Status' WHERE case_num='$case_num'";
                                $res = mysqli_query($mysqli,$sqliU);
								
								$bcdata="ID:".$id.", User: ".$uname.",Case No.: ".$case_num.", Status: ".$Status;
        					crimechain($id,$uname,$bcdata,'case');
							
                                if($res==1){
                                    ?>
                                <div class="alert alert-warning sammac animated shake" id="sams1">
                          <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong> Successfully </strong><?php echo'You Have Updated your status successfully';?></div>

                                    <?php
                                }
                                
                                
                  
                            }

                        ?>
                       
                <div class="line"></div>
<div class="row">
<div class="col-md-8">
    
    <div class="col-md-9">
    <div class="panel panel-default sammacmedia">
            <div class="panel-heading">Update Case Details</div>
        <div class="panel-body">
            <form method="post" action="update.php">
        <div class="row form-group">
          <div class="col-lg-12">
            <label>Case Number</label>
              <input type="text" class="form-control" name="case_num" required>
            </div>   
        </div>
           
                <div class="row form-group">
          <div class="col-lg-12">
            <label>Status</label>
              <input type="text" class="form-control" name="Status" required>
            </div>   
        </div>
                        

                <div class="row">
                <div class="col-md-12">
                  <button type="submit" name="submit" class="btn btn-danger btn-block"><span class="fa fa-lock"></span> Change</button>  
                </div>
                     
                </div>
            </form>

            </div>
                </div>
    </div>
     </div>
		</div>
                <div class="line"></div>
                <footer>
            <p class="text-center">
            Cyber Crime Reporting System &copy;<?php echo date("Y ");?>Copyright. All Rights Reserved    
            </p>
            </footer>
            </div>
            
        </div>

        <!-- jQuery CDN -->
         <script src="assets/js/jquery-1.10.2.js"></script>
         <!-- Bootstrap Js CDN -->
         <script src="assets/js/bootstrap.min.js"></script>

         <script type="text/javascript">
             $(document).ready(function () {
                 $('#sidebarCollapse').on('click', function () {
                     $('#sidebar').toggleClass('active');
                 });
             });
             $('sams').on('click', function(){
                 $('makota').addClass('animated tada');
             });
         </script>
         <script type="text/javascript">

        $(document).ready(function () {
 
            window.setTimeout(function() {
        $("#sams1").fadeTo(1000, 0).slideUp(1000, function(){
        $(this).remove(); 
        });
            }, 5000);
 
        });
    </script>
    </body>
</html>
