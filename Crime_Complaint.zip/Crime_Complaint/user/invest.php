<?php require_once('includes/session.php');
      require_once('includes/conn.php');
	  
	  $uname=$_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>Cyber Crime Reporting | SECURITY - DASHBOARD</title>

         <!-- Bootstrap CSS CDN -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- Our Custom CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/awesome/font-awesome.css">
        <link rel="stylesheet" href="assets/css/animate.css">
		<link rel="stylesheet" href="date_picker/jquery-ui.css">
<script src="date_picker/jquery-1.12.4.js"></script>
  <script src="date_picker/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#dob" ).datepicker();
  } );
  
  
  </script>
  <script language="javascript">
function getincident()
{
	if(document.form1.incident.value=="Facebook")
	{
	document.getElementById("a1").style.display="block";
	
	}
	else
	{
	
	//document.getElementById("a1").style.display="none";
	}
	
	if(document.form1.incident.value=="Instagram")
	{
	document.getElementById("a2").style.display="block";
	}
	else
	{
	//document.getElementById("a2").style.display="none";
	}
	
	if(document.form1.incident.value=="Whatsapp")
	{
	document.getElementById("a3").style.display="block";
	}
	else
	{
	//document.getElementById("a3").style.display="none";
	}
	
	if(document.form1.incident.value=="Youtube")
	{
	document.getElementById("a4").style.display="block";
	}
	else
	{
	//document.getElementById("a4").style.display="none";
	}
	if(document.form1.incident.value=="Twitter")
	{
	document.getElementById("a5").style.display="block";
	}
	else
	{
	//document.getElementById("a4").style.display="none";
	}
	
	if(document.form1.incident.value=="")
	{
	document.getElementById("a1").style.display="none";
	document.getElementById("a2").style.display="none";
	document.getElementById("a3").style.display="none";
	document.getElementById("a4").style.display="none";
	document.getElementById("a5").style.display="none";
	}

}
</script>
    </head>
    <body>

<?php
function crimechain($uid,$uname,$bcdata,$utype)
{
    ############
	$mon=date("m");
    $rdate=date("d-m-Y");
   $ch1=mktime(date('h')+5,date('i')+30,date('s'));
$rtime=date('h:i:s A',$ch1);
    
    $ff=fopen("../key.txt","r");
    $k=fread($ff,filesize("../key.txt"));
    fclose($ff);
    
    #bcdata="CID:"+uname+",Time:"+val1+",Unit:"+val2
    $dtime=$rdate.",".$rtime;

    $ff1=fopen("../js/d1.txt","r");
    $bc1=fread($ff1,filesize("../js/d1.txt"));
    fclose($ff1);
    
    $px="";
    if($k=="1")
	{
        $px="";
		$rn=rand(100,999);
        $result = md5($bcdata);
        $key=substr($result,0,32);
        
        $v=$k."##".$key."##".$bcdata."##".$dtime;

		$ff1=fopen("../js/d1.txt","w");
    	fwrite($ff1,$v);
   		fclose($ff1);
       
        
        $dictionary = array(
            "ID"=> "1",
            "Pre-hash"=> "00000000000000000000000000000000",
            "Hash"=> $key,
            "utype"=> $utype,
            "Date/Time"=> $dtime
        );

        $k1=$k;
        $k2=$k1+1;
        $k3=$k2;
        $ff1=fopen("../key.txt","w");
        fwrite($ff1,$k3);
        fclose($ff1);
		
		$ff1=fopen("../prehash.txt","w");
        fwrite($ff1,$key);
        fclose($ff1);

   	  
    }    
    else
	{
        $px=",";
        $pre_k="";
        $k1=$k;
        $k2=$k1-1;
        $k4=$k2;

		$ff1=fopen("../prehash.txt","r");
        $pre_hash=fread($ff1,filesize("../prehash.txt"));
        fclose($ff1);
		
        
        $g1=explode("#|",$bc1);
        foreach($g1 as $g2)
		{
            $g3=explode("##",$g2);
            if($k4==$g3[0])
			{
                $pre_k=$g3[1];
                break;
			}
		}
        
        $result = md5($bcdata);
        $key=$result;
        

        $v="#|".$k."##".$key."##".$bcdata."##".$dtime;

        $k3=$k2;
		
		$ff1=fopen("../key.txt","w");
        fwrite($ff1,$k3);
        fclose($ff1);
        
		$ff1=fopen("../js/d1.txt","a");
        fwrite($ff1,$v);
        fclose($ff1);

        
        $dictionary = array(
            "ID"=> $k,
            "Pre-hash"=> $pre_hash,
            "Hash"=> $key,
            "utype"=> $utype,
            "Date/Time"=> $dtime
        );
        
        $k21=$k+1;
        $k3=$k21;
		
		$ff1=fopen("../key.txt","w");
        fwrite($ff1,$k3);
        fclose($ff1);
		
    	$ff1=fopen("../prehash.txt","w");
        fwrite($ff1,$key);
        fclose($ff1);

      
	
 	}
    # Serializing json
	$m="";
    if(k=="1")
	{
        $m="w";
	}
    else
	{
       $m="a";
	 }
	//$json_data = json_encode($dictionary, JSON_PRETTY_PRINT);
	$json_data = json_encode($dictionary);
// Write JSON to file
//file_put_contents("../crimechain.json", $json_data);
		$ff1=fopen("../crimechain.json",$m);
        fwrite($ff1,$json_data);
        fclose($ff1);

}
?>

        <div class="wrapper">
            <!-- Sidebar Holder -->
            <nav id="sidebar" class="sammacmedia">
                <div class="sidebar-header">
                    <h3>Cyber Crime Reporting</h3>
                    <strong>CCR</strong>
                </div>

                <ul class="list-unstyled components">
                    
                    <li class="active">
                        <a href="invest.php">
                            <i class="fa fa-link"></i>
                            File Complaint
                        </a>
                    </li>
					<li >
                        <a href="v_users.php">
                            <i class="fa fa-link"></i>
                            View Status
                        </a>
                    </li>
					<li >
                        <a href="logout.php">
                            <i class="fa fa-link"></i>
                           Logout
                        </a>
                    </li>
                            
                </ul>
            </nav>

            <!-- Page Content Holder -->
            <div id="content">
             
                <div clas="col-md-12">
                    <img src="assets/image/line.png" class="img-thumbnail">
                    </div>
         
                
                <nav class="navbar navbar-default sammacmedia">
                    <div class="container-fluid">

                        <div class="navbar-header" id="sams">
                            <button type="button" id="sidebarCollapse" id="makota" class="btn btn-sam animated tada navbar-btn">
                                <i class="glyphicon glyphicon-align-left"></i>
                                <span>Menu</span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav navbar-right  makotasamuel">
                                <li><a href="#"><?php require_once('includes/name.php');?></a></li>
                                <li ><a href="logout.php"><i class="fa fa-power-off"> Logout</i></a></li>
           
                            </ul>
                        </div>
                    </div>
                </nav>

                <div class="line"></div>

                            <?php
							extract($_POST);
							
                            if(isset($mysqli,$_POST['submit'])){
                            $category = mysqli_real_escape_string($mysqli,$_POST['category']);
                            $severity = mysqli_real_escape_string($mysqli,$_POST['severity']);
							$dob = mysqli_real_escape_string($mysqli,$_POST['dob']);
                            $time = mysqli_real_escape_string($mysqli,$_POST['time']);
							$state = mysqli_real_escape_string($mysqli,$_POST['state']);
                            $district = mysqli_real_escape_string($mysqli,$_POST['district']);
							$locations = mysqli_real_escape_string($mysqli,$_POST['locations']);
                         //   $fb = mysqli_real_escape_string($mysqli,$_POST['fb1']);
							//$insta = mysqli_real_escape_string($mysqli,$_POST['ins1']);
                            //$whatsapp = mysqli_real_escape_string($mysqli,$_POST['what1']);
                           // $youtube = mysqli_real_escape_string($mysqli,$_POST['you1']);
                            //$twitter = mysqli_real_escape_string($mysqli,$_POST['twit1']);
                            $as = rand(1000,9999);     
                            $case_num = date("YmdHis").'.'.$as;
							$notes = mysqli_real_escape_string($mysqli,$_POST['notes']);
							
							$mq=mysqli_query($mysqli,"select max(id) from cases");
							$mr=mysqli_fetch_array($mq);
							$id=$mr['max(id)']+1;
                  
                            $sql = "INSERT INTO cases(id,category,severity,case_num,dob,time,state,district,incident,Status,notes,uname)VALUES($id,'$category','$severity','$case_num','$dob','$time','$state','$district','$locations',' Complaint Submitted ','$notes','$uname')";
                            $results = mysqli_query($mysqli,$sql);
							
							
							//$qq=mysql_query("select * from cases order by id desc limit 0,1");
							//$rr=mysqli_fetch_array($qq);
							//$mid=$rr['id'];
							
							$bcdata="ID:".$id.", User: ".$uname.", Case: ".$category.", Severity: ".$severity.", Case No.: ".$case_num;
        					crimechain($id,$uname,$bcdata,'case');
                        if($results==1){
                              ?>
                        <div class="alert alert-success strover animated bounce" id="sams1">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong> Successfully! </strong><?php echo'Case has successfully added';?></div>
                        <?php

                          }else{
                                ?>
                        <div class="alert alert-danger samuel animated shake" id="sams1">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong> Danger! </strong><?php echo'OOPS something went wrong';?></div>
            
                        <?php    
                          }      
                
            }
                
                ?>

		<div class="panel panel-default sammacmedia">
            <div class="panel-heading">Complaint</div>
        <div class="panel-body">
            <form id="form1" name="form1" method="post" action="invest.php">
        <div class="row form-group">
          <div class="col-lg-6">
            <label>Select Complaint Category</label>
             
                    <select class="form-control" name="category">
              
                <option>Murder</option>  
                <option>Kidnapping</option>    
 <option>Scam</option>    
 <option>Drugs</option>    
                       
                       </select>
            </div>  
            <div class="col-lg-6">
            <label>Case Severity</label>
                <select class="form-control" name="severity">
                <option>Normal</option>
                <option>Critical</option>  
                <option>Danger</option>    
                </select>
            </div>
			<div class="col-lg-6">
            <label>Incident Occured Date</label>
           
                <input class="form-control" type="text" name="dob" id="dob" />

            </div>
			<div class="col-lg-6">
            <label>Incident Occured Time</label>
           
                <input class="form-control" type="text" name="time"  />

            </div>
			<div class="col-lg-6">
            <label>State</label>
                <select class="form-control" name="state">
                <option>Tamilnadu</option>
                   
                </select>
            </div>
			<div class="col-lg-6">
            <label>District</label>
                <select class="form-control" name="district">
			<option>Trichy</option>
              <option>Tanjore</option>
              <option>Chennai</option>
              <option>Coimbatore</option>
              <option>Madurai</option>
              <option>Salem</option>
              <option>Namakkal</option>
              <option>Karur</option>
              <option>Erode</option>
                </select>
            </div>
			<div class="col-lg-6">
            <label>Where did the incident occur Location?</label>
                
	  <input class="form-control" type="text" name="locations"  />
				
            </div>
			<tr>
		<div style="display:none" id="a1">
          Facebook ID
          <input type="text" name="fb1"  /><span id="aa1"></span>     

		  </div>
        <div style="display:none" id="a2">
         Instagram ID
          <input type="text" name="ins1"  /><span id="aa2"></span>        </div>
        <div style="display:none" id="a3">
          Whatsapp Number
          <input type="text" name="what1"  /><span id="aa3"></span>        </div>
        <div style="display:none" id="a4">
          Channel name
          <input type="text" name="you1" /><span id="aa4"></span>        </div>
		  <div style="display:none" id="a5">
          Twitter ID
          <input type="text" name="twit1" /><span id="aa5"></span>        </div>
		  </tr>
		  		 
           </div>
                <div class="row form-group">
          <div class="col-lg-12">
              <textarea class="form-control" id="editor" name="notes"></textarea>
            </div>  
             
           </div>
                
                <div class="row">
                <div class="col-md-6">
                  <button type="submit" name="submit" class="btn btn-suc btn-block"><span class="fa fa-plus"></span> Process</button>  
                </div>
                     <div class="col-md-6">
                  <button type="reset" class="btn btn-dan btn-block"><span class="fa fa-times"></span> Cancel</button>  
                </div>
                </div>
            </form>

            </div>
                </div>
                <div class="line"></div>
                <footer>
            <p class="text-center">
            Cyber Crime Reporting System &copy;<?php echo date("Y ");?>Copyright. All Rights Reserved    
            </p>
            </footer>
            </div>
            
        </div>
        <!-- jQuery CDN -->
         <script src="assets/js/jquery-1.10.2.js"></script>
         <!-- Bootstrap Js CDN -->
         <script src="assets/js/bootstrap.min.js"></script>
         <script src="vendors/ckeditor/sammacmedia.js"></script>

         <script type="text/javascript">
             $(document).ready(function () {
                 $('#sidebarCollapse').on('click', function () {
                     $('#sidebar').toggleClass('active');
                 });
             });
             $('sams').on('click', function(){
                 $('makota').addClass('animated tada');
             });
         </script>
         <script type="text/javascript">

        $(document).ready(function () {
 
            window.setTimeout(function() {
        $("#sams1").fadeTo(1000, 0).slideUp(1000, function(){
        $(this).remove(); 
        });
            }, 5000);
 
        });
              ClassicEditor
                .create( document.querySelector( '#editor' ) )
                .then( editor => {
                console.log( editor );
		} )
                .catch( error => {
                console.error( error );
		} );
    </script>
    </body>
</html>
