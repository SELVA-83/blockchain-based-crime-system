-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 01, 2025 at 04:22 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `caaz`
--

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE `cases` (
  `id` int(11) NOT NULL,
  `category` varchar(30) NOT NULL,
  `severity` varchar(30) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `time` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `district` varchar(30) NOT NULL,
  `incident` varchar(30) NOT NULL,
  `fb` varchar(30) NOT NULL,
  `insta` varchar(30) NOT NULL,
  `whatsapp` varchar(30) NOT NULL,
  `youtube` varchar(30) NOT NULL,
  `twitter` varchar(30) NOT NULL,
  `Status` varchar(35) NOT NULL,
  `notes` text NOT NULL,
  `case_num` varchar(30) NOT NULL,
  `uname` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`id`, `category`, `severity`, `dob`, `time`, `state`, `district`, `incident`, `fb`, `insta`, `whatsapp`, `youtube`, `twitter`, `Status`, `notes`, `case_num`, `uname`) VALUES
(1, 'Kidnapping', 'Critical', '28-04-2025', '04:30 PM', 'Tamilnadu', 'Trichy', 'Bus Stand', '', '', '', '', '', 'investigate', '<p>2 school children</p>', '20250430072903.8473', '');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `address` varchar(40) NOT NULL,
  `email` varchar(30) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `rdate` varchar(30) NOT NULL,
  UNIQUE KEY `uname` (`uname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `mobile`, `address`, `email`, `uname`, `pass`, `rdate`) VALUES
(1, 'Vijay', '9654254885', '56,BS Nagar', 'vijay@gmail.com', 'vijay', '123456', '30-04-2025');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `joined` varchar(30) NOT NULL,
  `type` varchar(10) NOT NULL,
  `permission` varchar(10) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `email`, `username`, `password`, `joined`, `type`, `permission`, `gender`, `phone`) VALUES
(1, 'Admin', 'admin', 'crime@gmail.com', 'admin', 'admin', '17 Apr 2025', 'user', '1', 'M', '9272777334');
